def play_instrument(instrument):
    instrument.play()

class Guitar:
    def play(self):
        print("playing the guitar")

class Piano:
    def play(self):
        print("playing the piano")

guitar = Guitar()
play_instrument(guitar)  # Output: playing the guitar

piano = Piano()
play_instrument(piano)  # Output: playing the piano
